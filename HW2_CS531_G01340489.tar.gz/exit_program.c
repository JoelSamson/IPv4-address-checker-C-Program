#include<stdlib.h>

//HW2_CS531 - Gaurav Singh (G01340489)

void exit_program(void)
{
	exit(0);
}
